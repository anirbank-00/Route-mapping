import './App.css';
import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import axios from 'axios';
import { Loader } from '@googlemaps/js-api-loader';

function App() {
  const [distance, setDistance] = useState(null);
  const [duration, setDuration] = useState(null);
  const [clickedPoints, setClickedPoints] = useState([]);
  const [distanceArray, setDistanceArray] = useState([]);
  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);

  const apiKey = 'AIzaSyA0BXJqFHa27pYwL2xkbOEqkbptJPGz55U';
  
  const origin = useMemo(() => ({ lat: 37.7749, lng: -122.4194 }), []); // San Francisco
  const destination = useMemo(() => ({ lat: 34.0522, lng: -118.2437 }), []); // Los Angeles

  // 5 waypoints along the path
  const waypoints = useMemo(() => [
    { lat: 37.4419, lng: -122.1430, name: "Point 1: Palo Alto" },
    { lat: 36.7783, lng: -119.4179, name: "Point 2: Fresno" },
    { lat: 35.3733, lng: -119.0187, name: "Point 3: Bakersfield" },
    { lat: 34.9233, lng: -118.7847, name: "Point 4: Palmdale" },
    { lat: 34.4208, lng: -118.6109, name: "Point 5: Northridge" }
  ], []);

  const calculateDistance = async () => {
    const originStr = '37.7749,-122.4194'; // San Francisco
    const destinationStr = '34.0522,-118.2437'; // Los Angeles

    const url = `https://maps.googleapis.com/maps/api/distancematrix/json?origins=${originStr}&destinations=${destinationStr}&key=${apiKey}`;

    try {
      const response = await axios.get(url);
      const result = response.data;
      const distanceInMeters = result.rows[0].elements[0].distance.value;
      const durationInSeconds = result.rows[0].elements[0].duration.value;
      setDistance(distanceInMeters);
      setDuration(durationInSeconds);
    } catch (error) {
      console.error('Error fetching data: ', error);
    }
  };

  const calculateDistanceBetweenPoints = async (point1, point2) => {
    const origin = `${point1.lat},${point1.lng}`;
    const destination = `${point2.lat},${point2.lng}`;
    const url = `https://maps.googleapis.com/maps/api/distancematrix/json?origins=${origin}&destinations=${destination}&key=${apiKey}`;

    try {
      const response = await axios.get(url);
      const result = response.data;
      const distanceInMeters = result.rows[0].elements[0].distance.value;
      return distanceInMeters;
    } catch (error) {
      console.error('Error calculating distance:', error);
      return null;
    }
  };

  const handleMapClick = async (event) => {
    const lat = event.latLng.lat();
    const lng = event.latLng.lng();
    const newPoint = { lat, lng, id: Date.now() };
    
    setClickedPoints(prev => {
      const updatedPoints = [...prev, newPoint];
      
      // Calculate distances between all consecutive points
      if (updatedPoints.length > 1) {
        const lastPoint = updatedPoints[updatedPoints.length - 2];
        calculateDistanceBetweenPoints(lastPoint, newPoint).then(distance => {
          if (distance !== null) {
            setDistanceArray(prevDistances => [
              ...prevDistances,
              {
                id: Date.now(),
                from: lastPoint,
                to: newPoint,
                distance: distance,
                formattedDistance: formatDistance(distance)
              }
            ]);
          }
        });
      }
      
      return updatedPoints;
    });

    // Add marker for clicked point
    if (mapInstanceRef.current) {
      // eslint-disable-next-line no-undef
      new google.maps.Marker({
        position: { lat, lng },
        map: mapInstanceRef.current,
        title: `Clicked Point ${clickedPoints.length + 1}`,
        icon: {
          url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(
            `<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25">
              <circle cx="12.5" cy="12.5" r="10" fill="#FF6B6B" stroke="#ffffff" stroke-width="2"/>
              <text x="12.5" y="17" text-anchor="middle" fill="white" font-size="10" font-weight="bold">C</text>
            </svg>`
          ),
          // eslint-disable-next-line no-undef
          scaledSize: new google.maps.Size(25, 25),
        },
      });
    }
  };

  const clearClickedPoints = () => {
    setClickedPoints([]);
    setDistanceArray([]);
    // Reinitialize map to clear markers
    if (mapInstanceRef.current) {
      initializeMap();
    }
  };

  const initializeMap = useCallback(async () => {
    const loader = new Loader({
      apiKey: apiKey,
      version: 'weekly',
    });

    try {
      const { Map } = await loader.importLibrary('maps');
      const { DirectionsService, DirectionsRenderer } = await loader.importLibrary('routes');

      const mapInstance = new Map(mapRef.current, {
        center: { lat: 36.1, lng: -120.5 }, // Center between SF and LA
        zoom: 6,
        mapTypeId: 'roadmap',
      });

      mapInstanceRef.current = mapInstance;

      // Add click listener to map
      mapInstance.addListener('click', handleMapClick);

      // Create directions service and renderer
      const directionsService = new DirectionsService();
      const directionsRenderer = new DirectionsRenderer({
        draggable: false,
        map: mapInstance,
        polylineOptions: {
          strokeColor: '#FF0000',
          strokeWeight: 4,
          strokeOpacity: 0.8,
        },
      });

      // Calculate and display route with waypoints
      const waypointObjects = waypoints.map(point => ({
        location: { lat: point.lat, lng: point.lng },
        stopover: true,
      }));

      directionsService.route(
        {
          origin: origin,
          destination: destination,
          waypoints: waypointObjects,
          optimizeWaypoints: false,
          // eslint-disable-next-line no-undef
          travelMode: google.maps.TravelMode.DRIVING,
        },
        (result, status) => {
          if (status === 'OK') {
            directionsRenderer.setDirections(result);
          } else {
            console.error('Directions request failed due to ' + status);
          }
        }
      );

      // Add custom markers for the 5 points
      waypoints.forEach((point, index) => {
        // eslint-disable-next-line no-undef
        new google.maps.Marker({
          position: { lat: point.lat, lng: point.lng },
          map: mapInstance,
          title: point.name,
          label: {
            text: `${index + 1}`,
            color: 'white',
            fontWeight: 'bold',
          },
          icon: {
            url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(
              `<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">
                <circle cx="15" cy="15" r="12" fill="#4285F4" stroke="#ffffff" stroke-width="2"/>
                <text x="15" y="20" text-anchor="middle" fill="white" font-size="12" font-weight="bold">${index + 1}</text>
              </svg>`
            ),
            // eslint-disable-next-line no-undef
            scaledSize: new google.maps.Size(30, 30),
          },
        });
      });

      // Add markers for start and end points
      // eslint-disable-next-line no-undef
      new google.maps.Marker({
        position: origin,
        map: mapInstance,
        title: 'Start: San Francisco',
        icon: {
          url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(
            `<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">
              <circle cx="15" cy="15" r="12" fill="#34A853" stroke="#ffffff" stroke-width="2"/>
              <text x="15" y="20" text-anchor="middle" fill="white" font-size="10" font-weight="bold">S</text>
            </svg>`
          ),
          // eslint-disable-next-line no-undef
          scaledSize: new google.maps.Size(30, 30),
        },
      });

      // eslint-disable-next-line no-undef
      new google.maps.Marker({
        position: destination,
        map: mapInstance,
        title: 'End: Los Angeles',
        icon: {
          url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(
            `<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30">
              <circle cx="15" cy="15" r="12" fill="#EA4335" stroke="#ffffff" stroke-width="2"/>
              <text x="15" y="20" text-anchor="middle" fill="white" font-size="10" font-weight="bold">E</text>
            </svg>`
          ),
          // eslint-disable-next-line no-undef
          scaledSize: new google.maps.Size(30, 30),
        },
      });

    } catch (error) {
      console.error('Error loading Google Maps:', error);
    }
  }, [apiKey, origin, destination, waypoints]);

  useEffect(() => {
    calculateDistance();
    initializeMap();
  }, [initializeMap]);

  const formatDistance = (meters) => {
    if (meters < 1000) {
      return `${meters} meters`;
    } else {
      return `${(meters / 1000).toFixed(2)} km`;
    }
  };

  const formatDuration = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  };

  return (
    <div className="App">
      <div className="header">
        <h1>Interactive Distance Calculator</h1>
        <p>Route from San Francisco to Los Angeles with 5 waypoints</p>
        <p className="instruction">Click anywhere on the map to add points and calculate distances automatically!</p>
      </div>
      
      <div className="info-panel">
        <button onClick={calculateDistance} className="calculate-btn">
          Recalculate SF-LA Distance
        </button>
        <button onClick={clearClickedPoints} className="clear-btn">
          Clear Clicked Points
        </button>
        {distance && (
          <div className="distance-info">
            <p><strong>SF-LA Distance:</strong> {formatDistance(distance)}</p>
            {duration && <p><strong>Estimated Duration:</strong> {formatDuration(duration)}</p>}
          </div>
        )}
      </div>

      <div className="map-container">
        <div ref={mapRef} className="map"></div>
      </div>

      <div className="results-section">
        <div className="waypoints-info">
          <h3>Predefined Waypoints</h3>
          <ul>
            {waypoints.map((point, index) => (
              <li key={index}>
                <strong>{point.name}</strong> - Lat: {point.lat.toFixed(4)}, Lng: {point.lng.toFixed(4)}
              </li>
            ))}
          </ul>
        </div>

        {clickedPoints.length > 0 && (
          <div className="clicked-points-info">
            <h3>Clicked Points ({clickedPoints.length})</h3>
            <ul>
              {clickedPoints.map((point, index) => (
                <li key={point.id}>
                  <strong>Point {index + 1}:</strong> Lat: {point.lat.toFixed(4)}, Lng: {point.lng.toFixed(4)}
                </li>
              ))}
            </ul>
          </div>
        )}

        {distanceArray.length > 0 && (
          <div className="distance-array-info">
            <h3>Distance Calculations ({distanceArray.length})</h3>
            <ul>
              {distanceArray.map((item, index) => (
                <li key={item.id}>
                  <strong>Segment {index + 1}:</strong> {item.formattedDistance}
                  <br />
                  <small>
                    From: ({item.from.lat.toFixed(4)}, {item.from.lng.toFixed(4)}) 
                    To: ({item.to.lat.toFixed(4)}, {item.to.lng.toFixed(4)})
                  </small>
                </li>
              ))}
            </ul>
            <div className="total-distance">
              <strong>Total Distance of Clicked Path: {
                formatDistance(distanceArray.reduce((sum, item) => sum + item.distance, 0))
              }</strong>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
